/**
 * Share2Inspire Job Saver — Indeed Parser
 * Extrai dados de vagas do Indeed
 */

(function() {
  'use strict';

  function extractJobData() {
    try {
      // Title
      const title =
        document.querySelector('h1.jobsearch-JobInfoHeader-title')?.textContent?.trim() ||
        document.querySelector('.jobsearch-JobInfoHeader-title span')?.textContent?.trim() ||
        document.querySelector('h2.jobTitle')?.textContent?.trim() ||
        document.querySelector('[data-testid="jobsearch-JobInfoHeader-title"]')?.textContent?.trim() ||
        document.querySelector('h1[class*="JobTitle"]')?.textContent?.trim() ||
        document.querySelector('.icl-u-xs-block .jobtitle')?.textContent?.trim() ||
        '';

      // Company
      const company =
        document.querySelector('[data-testid="inlineHeader-companyName"] a')?.textContent?.trim() ||
        document.querySelector('[data-testid="inlineHeader-companyName"]')?.textContent?.trim() ||
        document.querySelector('.jobsearch-InlineCompanyRating a')?.textContent?.trim() ||
        document.querySelector('.jobsearch-InlineCompanyRating div')?.textContent?.trim() ||
        document.querySelector('.icl-u-lg-mr--sm a')?.textContent?.trim() ||
        '';

      // Location
      const location =
        document.querySelector('[data-testid="inlineHeader-companyLocation"]')?.textContent?.trim() ||
        document.querySelector('[data-testid="job-location"]')?.textContent?.trim() ||
        document.querySelector('.jobsearch-JobInfoHeader-subtitle .css-1restlb')?.textContent?.trim() ||
        document.querySelector('.icl-u-xs-mt--xs .icl-u-textColor--secondary')?.textContent?.trim() ||
        '';

      // Salary
      let salary = '';
      const salaryEl =
        document.querySelector('#salaryInfoAndJobType span.css-19j1a75') ||
        document.querySelector('[data-testid="attribute_snippet_testid"]') ||
        document.querySelector('.jobsearch-JobMetadataHeader-item');
      if (salaryEl) {
        const text = salaryEl.textContent?.trim() || '';
        if (text.match(/[\$\€\£]|salary|salário|year|hour|month|ano|mês/i)) {
          salary = text;
        }
      }

      // Employment type
      let employmentType = '';
      const metaItems = document.querySelectorAll('.jobsearch-JobMetadataHeader-item, [data-testid="attribute_snippet_testid"]');
      metaItems.forEach(el => {
        const text = el.textContent?.trim()?.toLowerCase() || '';
        if (text.includes('full-time') || text.includes('tempo integral')) employmentType = 'full-time';
        else if (text.includes('part-time') || text.includes('tempo parcial')) employmentType = 'part-time';
        else if (text.includes('contract') || text.includes('contrato')) employmentType = 'contract';
        else if (text.includes('internship') || text.includes('estágio')) employmentType = 'internship';
        else if (text.includes('temporary') || text.includes('temporário')) employmentType = 'temporary';
      });

      // Description
      const description =
        document.querySelector('#jobDescriptionText')?.textContent?.trim()?.substring(0, 2000) ||
        document.querySelector('.jobsearch-jobDescriptionText')?.textContent?.trim()?.substring(0, 2000) ||
        '';

      return {
        title,
        company,
        location,
        salary,
        employmentType,
        description,
        url: window.location.href,
        source: 'indeed'
      };
    } catch (err) {
      console.error('[S2I] Indeed parser error:', err);
      return null;
    }
  }

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_JOB') {
      const data = extractJobData();
      sendResponse(data);
    }
    return true;
  });

  // Auto-extract on page load
  setTimeout(() => {
    const data = extractJobData();
    if (data && data.title) {
      chrome.runtime.sendMessage({ type: 'JOB_DATA', data });
    }
  }, 1500);
})();
