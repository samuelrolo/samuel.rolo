/**
 * Share2Inspire Job Saver — Adzuna Parser
 * Extrai dados de vagas do Adzuna (todos os domínios regionais)
 * Suporta: /jobs/details/, /jobs/search, páginas de listagem
 */

(function() {
  'use strict';

  let lastExtractedTitle = '';
  let extractionTimeout = null;

  function extractJobData() {
    try {
      const url = window.location.href;
      const isDetailPage = url.includes('/jobs/details/') || url.includes('/land/ad/');

      // ── Detail Page Extraction ──
      if (isDetailPage) {
        return extractDetailPage();
      }

      // ── Search Results Page — try to extract from highlighted/expanded job card ──
      return extractFromSearchResults();
    } catch (err) {
      console.error('[S2I] Adzuna parser error:', err);
      return null;
    }
  }

  function extractDetailPage() {
    // ── Title ──
    const title =
      document.querySelector('h1')?.textContent?.trim() ||
      document.querySelector('.ui-adp-content h1')?.textContent?.trim() ||
      document.querySelector('[class*="job-title"]')?.textContent?.trim() ||
      '';

    if (!title) return null;

    // ── Company ──
    const company =
      document.querySelector('.ui-company a')?.textContent?.trim() ||
      document.querySelector('.ui-company')?.textContent?.trim() ||
      document.querySelector('[class*="company"] a')?.textContent?.trim() ||
      document.querySelector('[data-type="company"]')?.textContent?.trim() ||
      '';

    // ── Location ──
    const location =
      document.querySelector('.ui-location')?.textContent?.trim() ||
      document.querySelector('[class*="location"]')?.textContent?.trim() ||
      '';

    // ── Salary ──
    let salary =
      document.querySelector('.ui-salary')?.textContent?.trim() ||
      '';
    // Clean up salary text
    if (salary) {
      salary = salary.replace(/\s+/g, ' ').trim();
    }

    // ── Employment type ──
    let employmentType = '';
    const bodyText = document.body.innerText?.toLowerCase() || '';
    // Check description and meta for employment type keywords
    const descText = (document.querySelector('.adp-body')?.textContent || '').toLowerCase();
    const fullText = descText || bodyText;

    if (fullText.includes('full-time') || fullText.includes('full time') || fullText.includes('tempo integral') || fullText.includes('permanent')) {
      employmentType = 'full-time';
    } else if (fullText.includes('part-time') || fullText.includes('part time') || fullText.includes('tempo parcial')) {
      employmentType = 'part-time';
    } else if (fullText.includes('contract') || fullText.includes('contrato')) {
      employmentType = 'contract';
    } else if (fullText.includes('internship') || fullText.includes('estágio')) {
      employmentType = 'internship';
    } else if (fullText.includes('temporary') || fullText.includes('temporário')) {
      employmentType = 'temporary';
    } else if (fullText.includes('freelance')) {
      employmentType = 'freelance';
    }

    // ── Description ──
    const description =
      document.querySelector('.adp-body')?.textContent?.trim()?.substring(0, 3000) ||
      document.querySelector('.ui-adp-content')?.textContent?.trim()?.substring(0, 3000) ||
      document.querySelector('[class*="description"]')?.textContent?.trim()?.substring(0, 3000) ||
      '';

    return {
      title: cleanText(title),
      company: cleanText(company),
      location: cleanText(location),
      salary,
      employmentType,
      description,
      url: window.location.href,
      source: 'adzuna'
    };
  }

  function extractFromSearchResults() {
    // On search results pages, try to extract from the first visible article
    // or from an expanded job card
    const articles = document.querySelectorAll('article');
    if (!articles.length) return null;

    // Try to find a highlighted or first article
    const article = articles[0];
    if (!article) return null;

    // ── Title ──
    const titleEl = article.querySelector('a[href*="/jobs/details/"]') ||
                    article.querySelector('h2 a') ||
                    article.querySelector('a');
    const title = titleEl?.textContent?.trim() || '';

    if (!title) return null;

    // ── Company ──
    const company =
      article.querySelector('.ui-company a')?.textContent?.trim() ||
      article.querySelector('.ui-company')?.textContent?.trim() ||
      article.querySelector('[class*="company"]')?.textContent?.trim() ||
      '';

    // ── Location ──
    const location =
      article.querySelector('.ui-location')?.textContent?.trim() ||
      article.querySelector('[class*="location"]')?.textContent?.trim() ||
      '';

    // ── Salary ──
    const salary =
      article.querySelector('.ui-salary')?.textContent?.trim() ||
      '';

    // ── URL ──
    const jobUrl = titleEl?.href || window.location.href;

    // ── Description (snippet from search results) ──
    const description = article.textContent?.trim()?.substring(0, 1000) || '';

    return {
      title: cleanText(title),
      company: cleanText(company),
      location: cleanText(location),
      salary: salary.replace(/\s+/g, ' ').trim(),
      employmentType: '',
      description,
      url: jobUrl,
      source: 'adzuna'
    };
  }

  function cleanText(text) {
    return text ? text.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim() : '';
  }

  function sendJobData() {
    const data = extractJobData();
    if (data && data.title && data.title !== lastExtractedTitle) {
      lastExtractedTitle = data.title;
      chrome.runtime.sendMessage({ type: 'JOB_DATA', data }).catch(() => {});
      console.log('[S2I] Adzuna job detected:', data.title, '-', data.company);
    }
  }

  // Listen for messages from side panel
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_JOB') {
      const data = extractJobData();
      sendResponse(data);
    }
    return true;
  });

  // Auto-extract when page loads (with delay for dynamic content)
  setTimeout(sendJobData, 2000);
  setTimeout(sendJobData, 4000); // retry in case content loaded slowly

  // Observe DOM changes (Adzuna may load content dynamically)
  const observer = new MutationObserver(() => {
    if (extractionTimeout) clearTimeout(extractionTimeout);
    extractionTimeout = setTimeout(sendJobData, 1500);
  });

  const targetNode = document.querySelector('.ui-main') ||
                     document.querySelector('.ui-adp-content') ||
                     document.querySelector('#main') ||
                     document.body;

  observer.observe(targetNode, {
    childList: true,
    subtree: true,
    characterData: false,
    attributes: false
  });

  // Also listen for URL changes (in case of SPA-like navigation)
  let lastUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      lastExtractedTitle = ''; // Reset to allow re-extraction
      setTimeout(sendJobData, 2000);
    }
  }, 1000);
})();
