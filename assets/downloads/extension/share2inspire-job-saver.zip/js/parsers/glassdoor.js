/**
 * Share2Inspire Job Saver — Glassdoor Parser
 * Extrai dados de vagas do Glassdoor
 */

(function() {
  'use strict';

  function extractJobData() {
    try {
      // Title
      const title =
        document.querySelector('[data-test="job-title"]')?.textContent?.trim() ||
        document.querySelector('.e1tk4kwz4')?.textContent?.trim() ||
        document.querySelector('h1[class*="JobTitle"]')?.textContent?.trim() ||
        document.querySelector('.css-1vg6q84.e1tk4kwz4')?.textContent?.trim() ||
        document.querySelector('[class*="jobTitle"]')?.textContent?.trim() ||
        '';

      // Company
      const company =
        document.querySelector('[data-test="employer-name"]')?.textContent?.trim() ||
        document.querySelector('.e1tk4kwz1')?.textContent?.trim() ||
        document.querySelector('[class*="EmployerName"]')?.textContent?.trim() ||
        document.querySelector('.css-87uc0g.e1tk4kwz1')?.textContent?.trim() ||
        '';

      // Location
      const location =
        document.querySelector('[data-test="location"]')?.textContent?.trim() ||
        document.querySelector('.e1tk4kwz5')?.textContent?.trim() ||
        document.querySelector('[class*="location"]')?.textContent?.trim() ||
        '';

      // Salary
      let salary = '';
      const salaryEl =
        document.querySelector('[data-test="salary-estimate"]') ||
        document.querySelector('[class*="SalaryEstimate"]') ||
        document.querySelector('[class*="salary"]');
      if (salaryEl) {
        salary = salaryEl.textContent?.trim() || '';
      }

      // Employment type
      let employmentType = '';
      const detailItems = document.querySelectorAll('[class*="JobDetails"] li, [data-test*="type"]');
      detailItems.forEach(el => {
        const text = el.textContent?.trim()?.toLowerCase() || '';
        if (text.includes('full-time') || text.includes('tempo integral')) employmentType = 'full-time';
        else if (text.includes('part-time') || text.includes('tempo parcial')) employmentType = 'part-time';
        else if (text.includes('contract') || text.includes('contrato')) employmentType = 'contract';
        else if (text.includes('internship') || text.includes('estágio')) employmentType = 'internship';
        else if (text.includes('temporary') || text.includes('temporário')) employmentType = 'temporary';
      });

      // Description
      const description =
        document.querySelector('[class*="JobDescription"]')?.textContent?.trim()?.substring(0, 2000) ||
        document.querySelector('.jobDescriptionContent')?.textContent?.trim()?.substring(0, 2000) ||
        document.querySelector('#JobDescriptionContainer')?.textContent?.trim()?.substring(0, 2000) ||
        '';

      return {
        title,
        company,
        location,
        salary,
        employmentType,
        description,
        url: window.location.href,
        source: 'glassdoor'
      };
    } catch (err) {
      console.error('[S2I] Glassdoor parser error:', err);
      return null;
    }
  }

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_JOB') {
      const data = extractJobData();
      sendResponse(data);
    }
    return true;
  });

  // Auto-extract on page load
  setTimeout(() => {
    const data = extractJobData();
    if (data && data.title) {
      chrome.runtime.sendMessage({ type: 'JOB_DATA', data });
    }
  }, 1500);
})();
