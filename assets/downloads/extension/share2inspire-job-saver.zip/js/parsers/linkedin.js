/**
 * Share2Inspire Job Saver — LinkedIn Parser
 * Extrai dados de vagas do LinkedIn Jobs
 * Suporta: /jobs/view/, /jobs/collections/, /jobs/search/, /job/
 */

(function() {
  'use strict';

  let lastExtractedTitle = '';
  let extractionTimeout = null;

  function extractJobData() {
    try {
      // ── Title ──
      // LinkedIn uses different selectors depending on the page type
      const title =
        // New unified top card (most common in 2024+)
        document.querySelector('.job-details-jobs-unified-top-card__job-title h1 a')?.textContent?.trim() ||
        document.querySelector('.job-details-jobs-unified-top-card__job-title h1')?.textContent?.trim() ||
        document.querySelector('.job-details-jobs-unified-top-card__job-title')?.textContent?.trim() ||
        // Older unified top card
        document.querySelector('.jobs-unified-top-card__job-title')?.textContent?.trim() ||
        // Side panel in collections/search
        document.querySelector('.jobs-search__job-details--container h1')?.textContent?.trim() ||
        document.querySelector('.jobs-details__main-content h1')?.textContent?.trim() ||
        // Right panel header
        document.querySelector('.jobs-details-top-card__job-title')?.textContent?.trim() ||
        // Generic fallbacks
        document.querySelector('h1.t-24')?.textContent?.trim() ||
        document.querySelector('.t-24.t-bold.inline')?.textContent?.trim() ||
        document.querySelector('h1.topcard__title')?.textContent?.trim() ||
        document.querySelector('h2.t-24')?.textContent?.trim() ||
        // Very generic — any h1 in the job details area
        document.querySelector('.scaffold-layout__detail h1')?.textContent?.trim() ||
        document.querySelector('.jobs-search__job-details h1')?.textContent?.trim() ||
        '';

      if (!title) return null;

      // ── Company ──
      const company =
        document.querySelector('.job-details-jobs-unified-top-card__company-name a')?.textContent?.trim() ||
        document.querySelector('.job-details-jobs-unified-top-card__company-name')?.textContent?.trim() ||
        document.querySelector('.jobs-unified-top-card__company-name a')?.textContent?.trim() ||
        document.querySelector('.jobs-details-top-card__company-url')?.textContent?.trim() ||
        document.querySelector('.topcard__org-name-link')?.textContent?.trim() ||
        document.querySelector('.jobs-details__main-content .jobs-unified-top-card__subtitle-primary-grouping a')?.textContent?.trim() ||
        // Fallback: look for company in the primary description area
        document.querySelector('.job-details-jobs-unified-top-card__primary-description-container .app-aware-link')?.textContent?.trim() ||
        '';

      // ── Location ──
      const location =
        document.querySelector('.job-details-jobs-unified-top-card__bullet')?.textContent?.trim() ||
        document.querySelector('.jobs-unified-top-card__bullet')?.textContent?.trim() ||
        document.querySelector('.jobs-details-top-card__bullet')?.textContent?.trim() ||
        document.querySelector('.topcard__flavor--bullet')?.textContent?.trim() ||
        // Try the primary description container (often has "Location · Type")
        (() => {
          const desc = document.querySelector('.job-details-jobs-unified-top-card__primary-description-container');
          if (desc) {
            const spans = desc.querySelectorAll('span');
            for (const span of spans) {
              const text = span.textContent?.trim();
              if (text && !text.includes('·') && text.length > 3 && text.length < 100 && !text.includes('@')) {
                return text;
              }
            }
          }
          return '';
        })() ||
        '';

      // ── Salary ──
      let salary = '';
      const allInsights = document.querySelectorAll(
        '.job-details-jobs-unified-top-card__job-insight span, ' +
        '.jobs-unified-top-card__job-insight span, ' +
        '.salary-main-rail__data-body, ' +
        '[class*="salary"]'
      );
      allInsights.forEach(el => {
        const text = el.textContent?.trim() || '';
        if (text.match(/[\$\€\£]|salary|salário|\/yr|\/hour|\/ano|\/mês|k\s*-\s*\d/i)) {
          salary = text;
        }
      });

      // ── Employment type ──
      let employmentType = '';
      const typeSelectors = [
        '.job-details-jobs-unified-top-card__job-insight span',
        '.jobs-unified-top-card__job-insight span',
        '.job-details-jobs-unified-top-card__primary-description-container span',
        '.jobs-details-top-card__job-insight span'
      ];
      for (const selector of typeSelectors) {
        document.querySelectorAll(selector).forEach(el => {
          const text = el.textContent?.trim()?.toLowerCase() || '';
          if (text.includes('full-time') || text.includes('tempo integral') || text.includes('full time')) employmentType = 'full-time';
          else if (text.includes('part-time') || text.includes('tempo parcial') || text.includes('part time')) employmentType = 'part-time';
          else if (text.includes('contract') || text.includes('contrato')) employmentType = 'contract';
          else if (text.includes('internship') || text.includes('estágio')) employmentType = 'internship';
          else if (text.includes('temporary') || text.includes('temporário')) employmentType = 'temporary';
          else if (text.includes('freelance')) employmentType = 'freelance';
          // Also check for on-site/remote/hybrid tags
          if (text.includes('on-site') || text.includes('presencial')) { /* keep type */ }
          if (text.includes('remote') || text.includes('remoto')) { /* keep type */ }
        });
        if (employmentType) break;
      }

      // ── Description ──
      const description =
        document.querySelector('.jobs-description__content .jobs-box__html-content')?.textContent?.trim()?.substring(0, 3000) ||
        document.querySelector('.jobs-description__content')?.textContent?.trim()?.substring(0, 3000) ||
        document.querySelector('.jobs-box__html-content')?.textContent?.trim()?.substring(0, 3000) ||
        document.querySelector('#job-details')?.textContent?.trim()?.substring(0, 3000) ||
        document.querySelector('.jobs-description-content__text')?.textContent?.trim()?.substring(0, 3000) ||
        '';

      return {
        title: title.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim(),
        company: company.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim(),
        location: location.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim(),
        salary,
        employmentType,
        description,
        url: window.location.href,
        source: 'linkedin'
      };
    } catch (err) {
      console.error('[S2I] LinkedIn parser error:', err);
      return null;
    }
  }

  function sendJobData() {
    const data = extractJobData();
    if (data && data.title && data.title !== lastExtractedTitle) {
      lastExtractedTitle = data.title;
      chrome.runtime.sendMessage({ type: 'JOB_DATA', data }).catch(() => {});
      console.log('[S2I] Job detected:', data.title, '-', data.company);
    }
  }

  // Listen for messages from side panel
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_JOB') {
      const data = extractJobData();
      sendResponse(data);
    }
    return true;
  });

  // Auto-extract when page loads (with delay for dynamic content)
  setTimeout(sendJobData, 2000);
  setTimeout(sendJobData, 4000); // retry in case content loaded slowly

  // Observe DOM changes for SPA navigation (LinkedIn is a SPA)
  const observer = new MutationObserver(() => {
    if (extractionTimeout) clearTimeout(extractionTimeout);
    extractionTimeout = setTimeout(sendJobData, 1500);
  });

  // Watch for changes in the job details panel
  const targetNode = document.querySelector('.scaffold-layout__detail') ||
                     document.querySelector('.jobs-search__job-details') ||
                     document.querySelector('#main') ||
                     document.body;

  observer.observe(targetNode, {
    childList: true,
    subtree: true,
    characterData: false,
    attributes: false
  });

  // Also listen for URL changes (SPA navigation)
  let lastUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      lastExtractedTitle = ''; // Reset to allow re-extraction
      setTimeout(sendJobData, 2000);
    }
  }, 1000);
})();
