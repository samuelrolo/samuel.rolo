/**
 * Share2Inspire Job Saver — Background Service Worker
 * Gere a comunicação entre content scripts e o side panel
 */

// Store latest job data from content scripts
let latestJobData = null;

// Enable side panel to open when user clicks the extension icon
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('[S2I] Side panel behavior error:', error));

// Listen for messages from content scripts and side panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'JOB_DATA') {
    latestJobData = message.data;
    // Also save to storage for persistence
    chrome.storage.local.set({ currentJob: message.data });
    // Notify side panel if it's open
    chrome.runtime.sendMessage({ type: 'JOB_DATA_UPDATED', data: latestJobData })
      .catch(() => { /* side panel not open yet */ });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'GET_JOB_DATA') {
    if (latestJobData) {
      sendResponse({ data: latestJobData });
    } else {
      chrome.storage.local.get('currentJob', (result) => {
        sendResponse({ data: result.currentJob || null });
      });
      return true; // async
    }
  }

  if (message.type === 'GET_LATEST_JOB') {
    sendResponse(latestJobData);
    return false;
  }

  if (message.type === 'CLEAR_JOB_DATA') {
    latestJobData = null;
    chrome.storage.local.remove('currentJob', () => {
      sendResponse({ success: true });
    });
    return true;
  }

  return true;
});

// When tab is updated (user navigates), clear old data
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    latestJobData = null;
    chrome.storage.local.remove('currentJob');
  }
});
