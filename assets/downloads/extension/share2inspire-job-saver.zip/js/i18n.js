/**
 * Share2Inspire Job Saver — Internacionalização (PT / EN)
 * Detecção automática do idioma do browser com fallback para PT
 */

const S2I_TRANSLATIONS = {
  pt: {
    // Header
    headerTitle: 'Job Saver',
    
    // Login
    loginTitle: 'Inicia sessão',
    loginDesc: 'Acede com a tua conta Share2Inspire para guardar vagas.',
    emailLabel: 'E-mail',
    emailPlaceholder: 'email@exemplo.com',
    passwordLabel: 'Palavra-passe',
    passwordPlaceholder: 'A tua palavra-passe',
    loginBtn: 'Entrar',
    registerLink: 'Ainda não tens conta? Regista-te',
    loginError: 'E-mail ou palavra-passe incorretos.',
    loginErrorGeneric: 'Erro ao iniciar sessão. Tenta novamente.',

    // Main view
    jobDetected: 'Vaga detectada automaticamente',
    titleLabel: 'Título da Vaga *',
    titlePlaceholder: 'Ex: Frontend Developer',
    companyLabel: 'Empresa',
    companyPlaceholder: 'Ex: Google',
    locationLabel: 'Localização',
    locationPlaceholder: 'Ex: Lisboa',
    salaryLabel: 'Salário',
    salaryPlaceholder: 'Ex: 40k-50k',
    typeLabel: 'Tipo de Emprego',
    typeSelect: 'Selecionar...',
    typeFullTime: 'Full-time',
    typePartTime: 'Part-time',
    typeContract: 'Contrato',
    typeFreelance: 'Freelance',
    typeInternship: 'Estágio',
    typeTemporary: 'Temporário',
    notesLabel: 'Notas pessoais',
    notesPlaceholder: 'Adiciona notas sobre esta vaga...',
    saveBtn: 'Guardar Vaga',
    savingBtn: 'A guardar...',
    savedSuccess: 'Vaga guardada com sucesso!',
    saveErrorDuplicate: 'Esta vaga já foi guardada anteriormente.',
    saveErrorGeneric: 'Erro ao guardar. Tenta novamente.',
    saveErrorTitle: 'O título da vaga é obrigatório.',
    viewSavedJobs: 'Ver as minhas vagas guardadas',
    logoutTitle: 'Sair',

    // No job view
    noJobTitle: 'Nenhuma vaga detectada',
    noJobDesc: 'Navega para uma vaga de emprego no <strong>LinkedIn</strong>, <strong>Indeed</strong> ou <strong>Glassdoor</strong> e clica novamente neste ícone.',
    noJobManual: 'Ou preenche manualmente:',
    addManualBtn: 'Adicionar vaga manualmente',
  },

  en: {
    // Header
    headerTitle: 'Job Saver',

    // Login
    loginTitle: 'Sign in',
    loginDesc: 'Sign in with your Share2Inspire account to save jobs.',
    emailLabel: 'Email',
    emailPlaceholder: 'email@example.com',
    passwordLabel: 'Password',
    passwordPlaceholder: 'Your password',
    loginBtn: 'Sign In',
    registerLink: "Don't have an account? Sign up",
    loginError: 'Incorrect email or password.',
    loginErrorGeneric: 'Error signing in. Please try again.',

    // Main view
    jobDetected: 'Job detected automatically',
    titleLabel: 'Job Title *',
    titlePlaceholder: 'E.g.: Frontend Developer',
    companyLabel: 'Company',
    companyPlaceholder: 'E.g.: Google',
    locationLabel: 'Location',
    locationPlaceholder: 'E.g.: London',
    salaryLabel: 'Salary',
    salaryPlaceholder: 'E.g.: 40k-50k',
    typeLabel: 'Employment Type',
    typeSelect: 'Select...',
    typeFullTime: 'Full-time',
    typePartTime: 'Part-time',
    typeContract: 'Contract',
    typeFreelance: 'Freelance',
    typeInternship: 'Internship',
    typeTemporary: 'Temporary',
    notesLabel: 'Personal notes',
    notesPlaceholder: 'Add notes about this job...',
    saveBtn: 'Save Job',
    savingBtn: 'Saving...',
    savedSuccess: 'Job saved successfully!',
    saveErrorDuplicate: 'This job has already been saved.',
    saveErrorGeneric: 'Error saving. Please try again.',
    saveErrorTitle: 'Job title is required.',
    viewSavedJobs: 'View my saved jobs',
    logoutTitle: 'Sign out',

    // No job view
    noJobTitle: 'No job detected',
    noJobDesc: 'Navigate to a job listing on <strong>LinkedIn</strong>, <strong>Indeed</strong> or <strong>Glassdoor</strong> and click this icon again.',
    noJobManual: 'Or fill in manually:',
    addManualBtn: 'Add job manually',
  }
};

/**
 * Detecta o idioma do browser e retorna 'pt' ou 'en'
 */
function detectLanguage() {
  const lang = (navigator.language || navigator.userLanguage || 'pt').toLowerCase();
  return lang.startsWith('pt') ? 'pt' : 'en';
}

/**
 * Retorna a string traduzida para a key dada
 */
function t(key) {
  const lang = detectLanguage();
  return S2I_TRANSLATIONS[lang]?.[key] || S2I_TRANSLATIONS['pt']?.[key] || key;
}

/**
 * Aplica traduções a todos os elementos com data-i18n
 */
function applyTranslations() {
  const lang = detectLanguage();
  const strings = S2I_TRANSLATIONS[lang] || S2I_TRANSLATIONS['pt'];

  // Textos
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (strings[key]) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = strings[key];
      } else {
        el.innerHTML = strings[key];
      }
    }
  });

  // Atributos (title, placeholder, etc.)
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    if (strings[key]) el.title = strings[key];
  });
}
