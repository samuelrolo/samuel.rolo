/**
 * Share2Inspire Job Saver — Popup Logic
 * Autenticação via Supabase, guardar vagas, comunicação com content scripts
 */

const SUPABASE_URL = 'https://cvlumvgrbuolrnwrtrgz.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN2bHVtdmdyYnVvbHJud3J0cmd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgzNjQyNzMsImV4cCI6MjA4Mzk0MDI3M30.DAowq1KK84KDJEvHL-0ztb-zN6jyeC1qVLLDMpTaRLM';

let supabaseClient = null;
let currentUser = null;

// ── Init ──
document.addEventListener('DOMContentLoaded', async () => {
  // Apply translations
  applyTranslations();

  // Init Supabase
  supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
      storage: {
        getItem: (key) => new Promise((resolve) => {
          chrome.storage.local.get(key, (result) => resolve(result[key] || null));
        }),
        setItem: (key, value) => new Promise((resolve) => {
          chrome.storage.local.set({ [key]: value }, resolve);
        }),
        removeItem: (key) => new Promise((resolve) => {
          chrome.storage.local.remove(key, resolve);
        }),
      },
      autoRefreshToken: true,
      persistSession: true,
    }
  });

  // Check existing session
  const { data: { session } } = await supabaseClient.auth.getSession();
  if (session) {
    currentUser = session.user;
    await showMainView();
  } else {
    showView('view-login');
  }

  // Event listeners
  document.getElementById('btn-login').addEventListener('click', handleLogin);
  document.getElementById('login-password').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleLogin();
  });
  document.getElementById('btn-save').addEventListener('click', handleSave);
  document.getElementById('btn-logout').addEventListener('click', handleLogout);
  document.getElementById('btn-logout-2').addEventListener('click', handleLogout);
  document.getElementById('btn-add-manual')?.addEventListener('click', handleAddManual);
});

// ── Views ──
function showView(viewId) {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  document.getElementById(viewId)?.classList.remove('hidden');
}

async function showMainView() {
  // Set user info
  const profile = await fetchProfile();
  const name = profile ? `${profile.first_name || ''} ${profile.last_name || ''}`.trim() : (currentUser.email || '');
  const email = currentUser.email || '';
  const initials = name ? name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() : 'S2';

  document.getElementById('user-name').textContent = name || email;
  document.getElementById('user-email').textContent = email;
  document.getElementById('user-avatar').textContent = initials;

  // Try to get job data from content script
  const jobData = await getJobDataFromTab();

  if (jobData && jobData.title) {
    // Job detected — show form pre-filled
    document.getElementById('job-title').value = jobData.title || '';
    document.getElementById('job-company').value = jobData.company || '';
    document.getElementById('job-location').value = jobData.location || '';
    document.getElementById('job-salary').value = jobData.salary || '';
    document.getElementById('job-type').value = jobData.employmentType || '';
    document.getElementById('job-url').value = jobData.url || '';
    document.getElementById('job-source').value = jobData.source || '';
    document.getElementById('job-description').value = jobData.description || '';
    document.getElementById('job-status-bar').classList.remove('hidden');
    showView('view-main');
  } else {
    // No job detected
    showView('view-no-job');
  }
}

// ── Fetch user profile ──
async function fetchProfile() {
  try {
    const { data } = await supabaseClient
      .from('user_profiles')
      .select('first_name, last_name')
      .eq('id', currentUser.id)
      .single();
    return data;
  } catch {
    return null;
  }
}

// ── Get job data from active tab's content script ──
async function getJobDataFromTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return resolve(null);

      chrome.tabs.sendMessage(tabs[0].id, { type: 'EXTRACT_JOB' }, (response) => {
        if (chrome.runtime.lastError) {
          // Content script not loaded (not a supported job board)
          resolve(null);
        } else {
          resolve(response || null);
        }
      });
    });
  });
}

// ── Login ──
async function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const errorEl = document.getElementById('login-error');
  const btn = document.getElementById('btn-login');

  errorEl.classList.add('hidden');

  if (!email || !password) {
    errorEl.textContent = t('loginError');
    errorEl.classList.remove('hidden');
    return;
  }

  btn.disabled = true;
  btn.textContent = '...';

  try {
    const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });

    if (error) {
      errorEl.textContent = t('loginError');
      errorEl.classList.remove('hidden');
      btn.disabled = false;
      btn.textContent = t('loginBtn');
      return;
    }

    currentUser = data.user;
    await showMainView();
  } catch (err) {
    errorEl.textContent = t('loginErrorGeneric');
    errorEl.classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = t('loginBtn');
  }
}

// ── Save Job ──
async function handleSave() {
  const title = document.getElementById('job-title').value.trim();
  const company = document.getElementById('job-company').value.trim();
  const location = document.getElementById('job-location').value.trim();
  const salary = document.getElementById('job-salary').value.trim();
  const employmentType = document.getElementById('job-type').value;
  const notes = document.getElementById('job-notes').value.trim();
  const url = document.getElementById('job-url').value.trim();
  const source = document.getElementById('job-source').value.trim();
  const description = document.getElementById('job-description').value.trim();

  const errorEl = document.getElementById('save-error');
  const successEl = document.getElementById('save-success');
  const btn = document.getElementById('btn-save');

  errorEl.classList.add('hidden');
  successEl.classList.add('hidden');

  if (!title) {
    errorEl.textContent = t('saveErrorTitle');
    errorEl.classList.remove('hidden');
    return;
  }

  // Get current tab URL if not set
  let jobUrl = url;
  if (!jobUrl) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    jobUrl = tabs[0]?.url || '';
  }

  btn.disabled = true;
  const btnSpan = btn.querySelector('span');
  if (btnSpan) btnSpan.textContent = t('savingBtn');

  try {
    const { data, error } = await supabaseClient
      .from('saved_jobs')
      .insert({
        user_id: currentUser.id,
        title,
        company: company || null,
        location: location || null,
        salary: salary || null,
        employment_type: employmentType || null,
        notes: notes || null,
        url: jobUrl,
        source: source || detectSource(jobUrl),
        description: description || null,
        status: 'saved'
      })
      .select();

    if (error) {
      if (error.code === '23505') {
        // Duplicate
        errorEl.textContent = t('saveErrorDuplicate');
      } else {
        errorEl.textContent = t('saveErrorGeneric');
        console.error('Save error:', error);
      }
      errorEl.classList.remove('hidden');
    } else {
      successEl.classList.remove('hidden');
      // Disable save button after success
      btn.style.display = 'none';
    }
  } catch (err) {
    errorEl.textContent = t('saveErrorGeneric');
    errorEl.classList.remove('hidden');
    console.error('Save exception:', err);
  }

  btn.disabled = false;
  if (btnSpan) btnSpan.textContent = t('saveBtn');
}

// ── Detect source from URL ──
function detectSource(url) {
  if (!url) return 'other';
  if (url.includes('linkedin.com')) return 'linkedin';
  if (url.includes('indeed.com')) return 'indeed';
  if (url.includes('glassdoor.')) return 'glassdoor';
  if (url.includes('adzuna.')) return 'adzuna';
  return 'other';
}

// ── Logout ──
async function handleLogout() {
  await supabaseClient.auth.signOut();
  currentUser = null;
  showView('view-login');
}

// ── Add Manual ──
function handleAddManual() {
  // Switch to main view with empty form
  document.getElementById('job-title').value = '';
  document.getElementById('job-company').value = '';
  document.getElementById('job-location').value = '';
  document.getElementById('job-salary').value = '';
  document.getElementById('job-type').value = '';
  document.getElementById('job-notes').value = '';
  document.getElementById('job-url').value = '';
  document.getElementById('job-source').value = 'other';
  document.getElementById('job-description').value = '';
  document.getElementById('job-status-bar').classList.add('hidden');
  document.getElementById('save-error').classList.add('hidden');
  document.getElementById('save-success').classList.add('hidden');
  document.getElementById('btn-save').style.display = '';
  showView('view-main');
}
