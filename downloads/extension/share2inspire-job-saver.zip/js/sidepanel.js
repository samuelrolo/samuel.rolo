/**
 * Share2Inspire Job Saver — Side Panel Logic
 * Autenticação via Supabase, guardar vagas, comunicação com content scripts
 * Side Panel permanece aberto enquanto o utilizador navega
 */

const SUPABASE_URL = 'https://cvlumvgrbuolrnwrtrgz.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN2bHVtdmdyYnVvbHJud3J0cmd6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgzNjQyNzMsImV4cCI6MjA4Mzk0MDI3M30.DAowq1KK84KDJEvHL-0ztb-zN6jyeC1qVLLDMpTaRLM';

let supabaseClient = null;
let currentUser = null;
let lastDetectedUrl = '';

// ── Init ──
document.addEventListener('DOMContentLoaded', async () => {
  applyTranslations();

  supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
      storage: {
        getItem: (key) => new Promise((resolve) => {
          chrome.storage.local.get(key, (result) => resolve(result[key] || null));
        }),
        setItem: (key, value) => new Promise((resolve) => {
          chrome.storage.local.set({ [key]: value }, resolve);
        }),
        removeItem: (key) => new Promise((resolve) => {
          chrome.storage.local.remove(key, resolve);
        }),
      },
      autoRefreshToken: true,
      persistSession: true,
    }
  });

  // Check existing session
  const { data: { session } } = await supabaseClient.auth.getSession();
  if (session) {
    currentUser = session.user;
    await showMainView();
  } else {
    showView('view-login');
  }

  // Event listeners
  document.getElementById('btn-login').addEventListener('click', handleLogin);
  document.getElementById('login-password').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleLogin();
  });
  document.getElementById('btn-save').addEventListener('click', handleSave);
  document.getElementById('btn-logout').addEventListener('click', handleLogout);
  document.getElementById('btn-logout-2').addEventListener('click', handleLogout);
  document.getElementById('btn-add-manual')?.addEventListener('click', handleAddManual);
  document.getElementById('btn-refresh')?.addEventListener('click', handleRefresh);

  // Listen for job data updates from background (when user navigates to new job)
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'JOB_DATA_UPDATED' && message.data && currentUser) {
      fillJobForm(message.data);
    }
  });

  // Listen for tab changes to auto-detect new jobs
  chrome.tabs.onActivated?.addListener(async () => {
    if (currentUser) {
      await tryExtractFromCurrentTab();
    }
  });
});

// ── Views ──
function showView(viewId) {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  document.getElementById(viewId)?.classList.remove('hidden');
}

async function showMainView() {
  const profile = await fetchProfile();
  const name = profile ? `${profile.first_name || ''} ${profile.last_name || ''}`.trim() : (currentUser.email || '');
  const email = currentUser.email || '';
  const initials = name ? name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() : 'S2';

  document.getElementById('user-name').textContent = name || email;
  document.getElementById('user-email').textContent = email;
  document.getElementById('user-avatar').textContent = initials;

  // Load saved jobs count
  await updateSavedCount();

  // Try to get job data from content script
  await tryExtractFromCurrentTab();
}

async function tryExtractFromCurrentTab() {
  const jobData = await getJobDataFromTab();

  if (jobData && jobData.title) {
    fillJobForm(jobData);
    showView('view-main');
  } else {
    // Check if we have data from background
    const bgData = await getJobDataFromBackground();
    if (bgData && bgData.title) {
      fillJobForm(bgData);
      showView('view-main');
    } else {
      showView('view-no-job');
    }
  }
}

function fillJobForm(jobData) {
  document.getElementById('job-title').value = jobData.title || '';
  document.getElementById('job-company').value = jobData.company || '';
  document.getElementById('job-location').value = jobData.location || '';
  document.getElementById('job-salary').value = jobData.salary || '';
  document.getElementById('job-type').value = jobData.employmentType || '';
  document.getElementById('job-url').value = jobData.url || '';
  document.getElementById('job-source').value = jobData.source || '';
  document.getElementById('job-description').value = jobData.description || '';

  // Source display
  const sourceDisplay = document.getElementById('job-source-display');
  if (sourceDisplay) {
    const sourceNames = { linkedin: 'LinkedIn', indeed: 'Indeed', glassdoor: 'Glassdoor', adzuna: 'Adzuna', other: 'Outro' };
    sourceDisplay.value = sourceNames[jobData.source] || jobData.source || '';
  }

  // Description preview
  const descPreview = document.getElementById('job-description-preview');
  if (descPreview && jobData.description) {
    descPreview.textContent = jobData.description.substring(0, 300) + (jobData.description.length > 300 ? '...' : '');
    document.getElementById('description-group').style.display = '';
  } else if (descPreview) {
    document.getElementById('description-group').style.display = 'none';
  }

  document.getElementById('job-status-bar').classList.remove('hidden');
  document.getElementById('save-error').classList.add('hidden');
  document.getElementById('save-success').classList.add('hidden');
  document.getElementById('btn-save').style.display = '';

  lastDetectedUrl = jobData.url || '';
  showView('view-main');
}

// ── Fetch user profile ──
async function fetchProfile() {
  try {
    const { data } = await supabaseClient
      .from('user_profiles')
      .select('first_name, last_name')
      .eq('id', currentUser.id)
      .single();
    return data;
  } catch {
    return null;
  }
}

// ── Update saved jobs count ──
async function updateSavedCount() {
  try {
    const { count } = await supabaseClient
      .from('saved_jobs')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', currentUser.id);

    const counterEl = document.getElementById('saved-counter');
    const countText = document.getElementById('saved-count-text');
    if (count !== null && count > 0) {
      const lang = document.documentElement.lang?.startsWith('en') ? 'en' : 'pt';
      countText.textContent = lang === 'en' ? `${count} saved job${count !== 1 ? 's' : ''}` : `${count} vaga${count !== 1 ? 's' : ''} guardada${count !== 1 ? 's' : ''}`;
      counterEl.classList.remove('hidden');
    }
  } catch { /* ignore */ }
}

// ── Get job data from active tab's content script ──
async function getJobDataFromTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return resolve(null);

      chrome.tabs.sendMessage(tabs[0].id, { type: 'EXTRACT_JOB' }, (response) => {
        if (chrome.runtime.lastError) {
          resolve(null);
        } else {
          resolve(response || null);
        }
      });
    });
  });
}

// ── Get job data from background ──
async function getJobDataFromBackground() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'GET_JOB_DATA' }, (response) => {
      if (chrome.runtime.lastError) {
        resolve(null);
      } else {
        resolve(response?.data || null);
      }
    });
  });
}

// ── Refresh ──
async function handleRefresh() {
  const btn = document.getElementById('btn-refresh');
  btn.style.opacity = '0.5';
  btn.disabled = true;

  await tryExtractFromCurrentTab();

  setTimeout(() => {
    btn.style.opacity = '1';
    btn.disabled = false;
  }, 500);
}

// ── Login ──
async function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const errorEl = document.getElementById('login-error');
  const btn = document.getElementById('btn-login');

  errorEl.classList.add('hidden');

  if (!email || !password) {
    errorEl.textContent = t('loginError');
    errorEl.classList.remove('hidden');
    return;
  }

  btn.disabled = true;
  btn.textContent = '...';

  try {
    const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });

    if (error) {
      errorEl.textContent = t('loginError');
      errorEl.classList.remove('hidden');
      btn.disabled = false;
      btn.textContent = t('loginBtn');
      return;
    }

    currentUser = data.user;
    await showMainView();
  } catch (err) {
    errorEl.textContent = t('loginErrorGeneric');
    errorEl.classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = t('loginBtn');
  }
}

// ── Save Job ──
async function handleSave() {
  const title = document.getElementById('job-title').value.trim();
  const company = document.getElementById('job-company').value.trim();
  const location = document.getElementById('job-location').value.trim();
  const salary = document.getElementById('job-salary').value.trim();
  const employmentType = document.getElementById('job-type').value;
  const notes = document.getElementById('job-notes').value.trim();
  const url = document.getElementById('job-url').value.trim();
  const source = document.getElementById('job-source').value.trim();
  const description = document.getElementById('job-description').value.trim();

  const errorEl = document.getElementById('save-error');
  const successEl = document.getElementById('save-success');
  const btn = document.getElementById('btn-save');

  errorEl.classList.add('hidden');
  successEl.classList.add('hidden');

  if (!title) {
    errorEl.textContent = t('saveErrorTitle');
    errorEl.classList.remove('hidden');
    return;
  }

  let jobUrl = url;
  if (!jobUrl) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    jobUrl = tabs[0]?.url || '';
  }

  btn.disabled = true;
  const btnSpan = btn.querySelector('span');
  if (btnSpan) btnSpan.textContent = t('savingBtn');

  try {
    const { data, error } = await supabaseClient
      .from('saved_jobs')
      .insert({
        user_id: currentUser.id,
        title,
        company: company || null,
        location: location || null,
        salary: salary || null,
        employment_type: employmentType || null,
        notes: notes || null,
        url: jobUrl,
        source: source || detectSource(jobUrl),
        description: description || null,
        status: 'saved'
      })
      .select();

    if (error) {
      if (error.code === '23505') {
        errorEl.textContent = t('saveErrorDuplicate');
      } else {
        errorEl.textContent = t('saveErrorGeneric');
        console.error('Save error:', error);
      }
      errorEl.classList.remove('hidden');
    } else {
      successEl.classList.remove('hidden');
      btn.style.display = 'none';
      await updateSavedCount();
    }
  } catch (err) {
    errorEl.textContent = t('saveErrorGeneric');
    errorEl.classList.remove('hidden');
    console.error('Save exception:', err);
  }

  btn.disabled = false;
  if (btnSpan) btnSpan.textContent = t('saveBtn');
}

// ── Detect source from URL ──
function detectSource(url) {
  if (!url) return 'other';
  if (url.includes('linkedin.com')) return 'linkedin';
  if (url.includes('indeed.com') || url.includes('indeed.co.uk') || url.includes('indeed.pt')) return 'indeed';
  if (url.includes('glassdoor.')) return 'glassdoor';
  if (url.includes('adzuna.')) return 'adzuna';
  return 'other';
}

// ── Logout ──
async function handleLogout() {
  await supabaseClient.auth.signOut();
  currentUser = null;
  showView('view-login');
}

// ── Add Manual ──
function handleAddManual() {
  document.getElementById('job-title').value = '';
  document.getElementById('job-company').value = '';
  document.getElementById('job-location').value = '';
  document.getElementById('job-salary').value = '';
  document.getElementById('job-type').value = '';
  document.getElementById('job-notes').value = '';
  document.getElementById('job-url').value = '';
  document.getElementById('job-source').value = 'other';
  document.getElementById('job-description').value = '';
  if (document.getElementById('job-source-display')) {
    document.getElementById('job-source-display').value = 'Manual';
  }
  if (document.getElementById('description-group')) {
    document.getElementById('description-group').style.display = 'none';
  }
  document.getElementById('job-status-bar').classList.add('hidden');
  document.getElementById('save-error').classList.add('hidden');
  document.getElementById('save-success').classList.add('hidden');
  document.getElementById('btn-save').style.display = '';
  showView('view-main');
}
// ==========================================
// ── LÓGICA DO CAREER ADVISOR E PAYWALL ──
// ==========================================

const EDGE_FUNCTION_URL = 'https://cvlumvgrbuolrnwrtrgz.supabase.co/functions/v1/hyper-task'; // ← Substitui pelo nome correto da tua função

let isUserPro = false;

// ── LÓGICA DO SIMULADOR DE ENTREVISTA (VOZ) ──
let s2iMediaRecorder = null;
let s2iAudioChunks =[];

// 1. Injetar a verificação de PRO no showMainView
const originalShowMainView = showMainView;
showMainView = async function() {
  await checkProStatus(); // Verifica a subscrição antes de mostrar a view
  await originalShowMainView();
  
  // Lógica da Interface Híbrida
  const advisorSection = document.getElementById('career-advisor-section');
  const upsellSection = document.getElementById('pro-upsell-section');
  const userNameEl = document.getElementById('user-name');
  
  if (advisorSection && upsellSection) {
    if (isUserPro) {
      advisorSection.classList.remove('hidden');
      upsellSection.classList.add('hidden');
      if (!document.getElementById('badge-pro')) {
        const badge = document.createElement('span');
        badge.id = 'badge-pro';
        badge.className = 'pro-badge';
        badge.textContent = 'PRO';
        userNameEl.appendChild(badge);
      }
    } else {
      advisorSection.classList.add('hidden');
      upsellSection.classList.remove('hidden');
      const badge = document.getElementById('badge-pro');
      if (badge) badge.remove();
    }
  }
};

// 2. Verificar na Base de Dados
async function checkProStatus() {
  if (!currentUser) return false;
  try {
    const { data } = await supabaseClient
      .from('subscriptions') // Tabela de subscrições (ajusta se tiveres outro nome)
      .select('status')
      .eq('user_id', currentUser.id)
      .eq('status', 'active')
      .maybeSingle();
    isUserPro = !!data;
    return isUserPro;
  } catch (err) {
    console.error('Erro a verificar Pro:', err);
    return false;
  }
}

// 3. Event Listeners da IA
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btn-check-match')?.addEventListener('click', handleCheckMatch);
  document.getElementById('btn-generate-cover')?.addEventListener('click', handleGenerateCoverLetter);
  document.getElementById('btn-record-audio')?.addEventListener('click', startMockInterview);
  document.getElementById('btn-stop-audio')?.addEventListener('click', stopMockInterview);
  document.getElementById('btn-next-question')?.addEventListener('click', loadNextQuestion);
});

// 4. Lógica: Check Match
async function handleCheckMatch() {
  const btn = document.getElementById('btn-check-match');
  const resultsContainer = document.getElementById('ai-results-container');
  const jobDescription = document.getElementById('job-description').value;

  if (!jobDescription || jobDescription.length < 50) {
    alert("Não foi possível detetar a descrição completa desta vaga. Abre a página principal da vaga.");
    return;
  }

  btn.disabled = true;
  btn.innerHTML = '⏳ A analisar o teu CV...';
  resultsContainer.classList.remove('hidden');
  resultsContainer.innerHTML = '<p style="text-align:center;">A cruzar o teu CV com a vaga...</p>';

  try {
    // Tentar primeiro por user_id, depois fallback por user_email
    let { data: cvData } = await supabaseClient.from('cv_analysis').select('cv_text').eq('user_id', currentUser.id).order('created_at', { ascending: false }).limit(1).single();
    if (!cvData || !cvData.cv_text) {
      const fallback = await supabaseClient.from('cv_analysis').select('cv_text').eq('user_email', currentUser.email).order('created_at', { ascending: false }).limit(1).single();
      cvData = fallback.data;
    }
    if (!cvData || !cvData.cv_text) throw new Error("Sem CV. Faz upload na plataforma primeiro.");

    const { data: { session } } = await supabaseClient.auth.getSession();
    const res = await fetch(EDGE_FUNCTION_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
      body: JSON.stringify({
        mode: 'cv_extraction',
        cv_text: cvData.cv_text,
        job_description: jobDescription,
        language: 'pt'
      })
    });
    const result = await res.json();

    if (result.success && result.job_match) {
      resultsContainer.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
          <strong>Score ATS:</strong> <span style="font-size:13px; font-weight:bold; color:var(--s2i-gold);">${result.job_match.ats_compatibility_score}%</span>
        </div>
        <p style="margin-bottom:8px;">${result.job_match.overall_fit}</p>
        <p><strong>✅ Tens:</strong> ${result.job_match.matched_keywords.join(', ')}</p>
        <p style="color:#dc2626;"><strong>❌ Falta:</strong> ${result.job_match.keyword_gaps.join(', ')}</p>`;
    } else {
      throw new Error("Erro na resposta da IA.");
    }
  } catch (error) {
    resultsContainer.innerHTML = `<p style="color:red;">${error.message}</p>`;
  } finally {
    btn.disabled = false;
    btn.innerHTML = 'Verificar Match com o meu CV';
  }
}

// 5. Lógica: Gerar Carta de Apresentação
async function handleGenerateCoverLetter() {
  const btn = document.getElementById('btn-generate-cover');
  const resultsContainer = document.getElementById('ai-results-container');
  btn.disabled = true;
  btn.innerHTML = '⏳ A escrever...';
  resultsContainer.classList.remove('hidden');
  resultsContainer.innerHTML = '<p style="text-align:center;">A redigir carta personalizada...</p>';

  try {
    const { data: { session } } = await supabaseClient.auth.getSession();
    const res = await fetch(EDGE_FUNCTION_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
      body: JSON.stringify({
        mode: 'career_coach',
        cover_letter: true,
        target_company: document.getElementById('job-company').value,
        target_role: document.getElementById('job-title').value,
        user_id: currentUser.id,
        language: 'pt'
      })
    });
    const result = await res.json();
    if (result.success) {
      resultsContainer.innerHTML = `<p style="white-space: pre-wrap;">${result.reply}</p>`;
    } else {
      throw new Error("Erro a gerar carta.");
    }
  } catch (error) {
    resultsContainer.innerHTML = `<p style="color:red;">${error.message}</p>`;
  } finally {
    btn.disabled = false;
    btn.innerHTML = 'Gerar Carta de Apresentação';
  }
}

// Helper: Obter o texto do CV do utilizador de forma segura
async function getUserCVText() {
  try {
    // Tentar primeiro por user_id, depois fallback por user_email
    let { data: cvData } = await supabaseClient
      .from('cv_analysis')
      .select('cv_text')
      .eq('user_id', currentUser.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    if (!cvData || !cvData.cv_text) {
      const fallback = await supabaseClient
        .from('cv_analysis')
        .select('cv_text')
        .eq('user_email', currentUser.email)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();
      cvData = fallback.data;
    }
    return cvData?.cv_text || '';
  } catch (err) {
    console.error('Erro ao obter CV:', err);
    return '';
  }
}

// 6. Lógica: Mock Interview (Gravação de Voz) — Versão Hiper-Resistente
// Helper: Verificar se a permissão do microfone já foi concedida
async function checkMicPermission() {
  try {
    const status = await navigator.permissions.query({ name: 'microphone' });
    return status.state; // 'granted', 'denied', ou 'prompt'
  } catch (e) {
    // Fallback: verificar via storage se já foi concedida na página dedicada
    return new Promise((resolve) => {
      chrome.storage.local.get('micPermissionGranted', (result) => {
        resolve(result.micPermissionGranted ? 'granted' : 'prompt');
      });
    });
  }
}

// Helper: Abrir a página dedicada para pedir permissão do microfone
function openMicPermissionPage() {
  chrome.tabs.create({
    url: chrome.runtime.getURL('mic-permission.html'),
    active: true
  });
}

async function startMockInterview() {
  const btnRecord = document.getElementById('btn-record-audio');
  const btnStop = document.getElementById('btn-stop-audio');
  
  try {
    // Feedback visual imediato
    btnRecord.textContent = 'A preparar microfone...';
    btnRecord.disabled = true;

    // 0. Verificar o estado da permissão do microfone
    const permState = await checkMicPermission();
    
    if (permState === 'denied') {
      alert('O acesso ao microfone está bloqueado.\n\nVai abrir uma página para ativares o microfone.\nDepois volta aqui e tenta novamente.');
      openMicPermissionPage();
      btnRecord.textContent = '🎤 Gravar Resposta';
      btnRecord.disabled = false;
      return;
    }

    // 1. Tentar pedir a stream de áudio
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { echoCancellation: true, noiseSuppression: true } 
      });
    } catch (mediaErr) {
      // Se falhar no Side Panel (NotAllowedError), abrir a página dedicada
      if (mediaErr.name === 'NotAllowedError' || mediaErr.name === 'NotReadableError') {
        console.warn('Side Panel não consegue aceder ao microfone. A abrir página de permissão...');
        alert('O Chrome precisa que atives o microfone numa página dedicada (limitação do Painel Lateral).\n\nVai abrir um separador para ativares. Depois volta aqui e carrega em "Gravar" novamente.');
        openMicPermissionPage();
        btnRecord.textContent = '🎤 Gravar Resposta';
        btnRecord.disabled = false;
        return;
      }
      throw mediaErr; // Re-throw outros erros
    }

    // 2. Preparar o gravador (deixando o Chrome escolher o formato ideal)
    s2iAudioChunks = [];
    s2iMediaRecorder = new MediaRecorder(stream);

    // 3. Recolher os dados do áudio
    s2iMediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) s2iAudioChunks.push(e.data);
    };

    // INICIA a gravação, guardando pedaços a cada 200ms (evita bugs de áudio vazio no Chrome)
    s2iMediaRecorder.start(200); 
    console.log('Gravação iniciada! Formato:', s2iMediaRecorder.mimeType);

    // 4. Mudar botões na Interface
    btnRecord.classList.add('hidden');
    btnStop.classList.remove('hidden');
    btnStop.classList.add('recording-active');
    
    const feedbackEl = document.getElementById('interview-feedback');
    if (feedbackEl) feedbackEl.classList.add('hidden');

    // Guardar que a permissão foi concedida com sucesso
    chrome.storage.local.set({ micPermissionGranted: true });

  } catch (err) {
    console.error('❌ Erro no microfone:', err);
    
    if (err.name === 'NotFoundError') {
      alert('Nenhum microfone foi detetado no teu computador.\nVerifica se tens um microfone ligado e tenta novamente.');
    } else {
      alert('Erro ao aceder ao microfone: ' + err.message);
    }
    
    // Reset ao botão
    btnRecord.textContent = '🎤 Gravar Resposta';
    btnRecord.disabled = false;
  }
}

async function stopMockInterview() {
  if (!s2iMediaRecorder || s2iMediaRecorder.state === 'inactive') return;

  const btnStop = document.getElementById('btn-stop-audio');
  const btnRecord = document.getElementById('btn-record-audio');
  
  // Feedback visual
  btnStop.textContent = '⏳ A analisar a tua voz...';
  btnStop.classList.remove('recording-active');
  btnStop.disabled = true;

  s2iMediaRecorder.onstop = async () => {
    try {
      // Usar o formato que o browser decidiu usar
      const actualMimeType = s2iMediaRecorder.mimeType || 'audio/webm';
      const audioBlob = new Blob(s2iAudioChunks, { type: actualMimeType });
      
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      
      reader.onloadend = async () => {
        const base64Audio = reader.result.split(',')[1];

        // Obter CV e Sessão usando o helper seguro
        const cvText = await getUserCVText();
        const { data: { session } } = await supabaseClient.auth.getSession();
        
        // Chamada à Edge Function
        const res = await fetch(EDGE_FUNCTION_URL, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json', 
            'Authorization': `Bearer ${session.access_token}` 
          },
          body: JSON.stringify({
            mode: 'mock_interview',
            audio_base64: base64Audio,
            mime_type: actualMimeType,
            cv_text: cvText || '',
            job_title: document.getElementById('job-title').value,
            company: document.getElementById('job-company').value,
            current_question: document.getElementById('interview-question').textContent,
            language: 'pt'
          })
        });

        const result = await res.json();
        
        if (result.success && result.feedback) {
          document.getElementById('fb-score').textContent = `${result.feedback.score || 85}/100`;
          document.getElementById('fb-tone').textContent = result.feedback.delivery_and_tone;
          document.getElementById('fb-content').textContent = result.feedback.content_critique;
          document.getElementById('fb-ideal').textContent = `"${result.feedback.improved_answer}"`;
          document.getElementById('interview-question').dataset.next = result.feedback.next_question;
          document.getElementById('interview-feedback').classList.remove('hidden');
        } else {
          throw new Error(result.error || "A IA não conseguiu gerar o feedback.");
        }
      };
    } catch (e) {
      console.error(e);
      alert('Erro ao processar a análise: ' + e.message);
    } finally {
      // Repor a interface ao estado inicial
      btnStop.classList.add('hidden');
      btnStop.textContent = '⏹️ Parar & Analisar';
      btnStop.disabled = false;
      btnRecord.classList.remove('hidden');
      btnRecord.textContent = '🎤 Gravar Resposta';
      btnRecord.disabled = false;
    }
  };

  // Parar a gravação
  s2iMediaRecorder.stop();
  
  // SUPER IMPORTANTE: Desligar a luz do microfone do browser à força!
  s2iMediaRecorder.stream.getTracks().forEach(track => track.stop());
}

function loadNextQuestion() {
  const nextQ = document.getElementById('interview-question').dataset.next;
  if (nextQ) document.getElementById('interview-question').textContent = `"${nextQ}"`;
  document.getElementById('interview-feedback').classList.add('hidden');
}