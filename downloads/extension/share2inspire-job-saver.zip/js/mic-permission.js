/**
 * Share2Inspire — Mic Permission Page
 * Esta página abre num tab normal para pedir permissão do microfone.
 * O Side Panel do Chrome NÃO consegue mostrar o diálogo de permissão,
 * por isso usamos esta página como intermediário.
 */

document.getElementById('btn-allow').addEventListener('click', async () => {
  const btn = document.getElementById('btn-allow');
  const statusEl = document.getElementById('status');

  btn.disabled = true;
  btn.textContent = 'A pedir acesso...';
  statusEl.textContent = '';
  statusEl.className = 'status info';

  try {
    // Pedir acesso ao microfone — isto mostra o diálogo do Chrome
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    // Permissão concedida! Parar a stream imediatamente (não precisamos de gravar aqui)
    stream.getTracks().forEach(track => track.stop());

    // Guardar flag para o Side Panel saber que a permissão foi concedida
    chrome.storage.local.set({ micPermissionGranted: true });

    statusEl.textContent = '✅ Microfone ativado com sucesso! Podes fechar este separador.';
    statusEl.className = 'status success';
    btn.textContent = '✅ Ativado!';

    // Fechar o tab automaticamente após 2 segundos
    setTimeout(() => {
      window.close();
    }, 2000);

  } catch (err) {
    console.error('Erro ao pedir permissão:', err);

    if (err.name === 'NotAllowedError') {
      statusEl.textContent = '❌ Permissão negada. Clica no ícone do cadeado 🔒 na barra de endereço para permitir o microfone.';
    } else if (err.name === 'NotFoundError') {
      statusEl.textContent = '❌ Nenhum microfone detetado. Verifica se tens um microfone ligado.';
    } else {
      statusEl.textContent = '❌ Erro: ' + err.message;
    }
    statusEl.className = 'status error';
    btn.textContent = 'Tentar Novamente';
    btn.disabled = false;
  }
});
