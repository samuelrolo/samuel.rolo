-- ============================================================
-- Share2Inspire — Migração: Tabela saved_jobs
-- Executar no SQL Editor do Supabase Dashboard
-- ============================================================

-- 1. Criar a tabela saved_jobs
CREATE TABLE IF NOT EXISTS public.saved_jobs (
  id            UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id       UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  company       TEXT,
  location      TEXT,
  salary        TEXT,
  employment_type TEXT,
  description   TEXT,
  url           TEXT NOT NULL DEFAULT '',
  source        TEXT DEFAULT 'other',
  status        TEXT NOT NULL DEFAULT 'saved'
                  CHECK (status IN ('saved','applied','interview','offer','rejected','archived')),
  notes         TEXT,
  excitement    SMALLINT CHECK (excitement IS NULL OR (excitement >= 1 AND excitement <= 5)),
  follow_up_date DATE,
  date_applied  DATE,
  deadline      DATE,
  job_posted_at TIMESTAMPTZ,
  saved_at      TIMESTAMPTZ DEFAULT now(),
  updated_at    TIMESTAMPTZ DEFAULT now()
);

-- 2. Índices para performance
CREATE INDEX IF NOT EXISTS idx_saved_jobs_user_id ON public.saved_jobs(user_id);
CREATE INDEX IF NOT EXISTS idx_saved_jobs_status  ON public.saved_jobs(status);
CREATE INDEX IF NOT EXISTS idx_saved_jobs_saved_at ON public.saved_jobs(saved_at DESC);

-- 3. Índice único para evitar duplicados (mesmo user + mesmo URL)
CREATE UNIQUE INDEX IF NOT EXISTS idx_saved_jobs_unique_url
  ON public.saved_jobs(user_id, url)
  WHERE url IS NOT NULL AND url != '';

-- 4. Trigger para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION public.update_saved_jobs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_saved_jobs_updated_at ON public.saved_jobs;
CREATE TRIGGER trg_saved_jobs_updated_at
  BEFORE UPDATE ON public.saved_jobs
  FOR EACH ROW
  EXECUTE FUNCTION public.update_saved_jobs_updated_at();

-- 5. Row Level Security (RLS) — cada utilizador só vê/edita as suas vagas
ALTER TABLE public.saved_jobs ENABLE ROW LEVEL SECURITY;

-- Policy: SELECT — utilizador vê apenas as suas vagas
CREATE POLICY "Users can view own saved jobs"
  ON public.saved_jobs
  FOR SELECT
  USING (auth.uid() = user_id);

-- Policy: INSERT — utilizador insere apenas para si
CREATE POLICY "Users can insert own saved jobs"
  ON public.saved_jobs
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Policy: UPDATE — utilizador atualiza apenas as suas vagas
CREATE POLICY "Users can update own saved jobs"
  ON public.saved_jobs
  FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policy: DELETE — utilizador apaga apenas as suas vagas
CREATE POLICY "Users can delete own saved jobs"
  ON public.saved_jobs
  FOR DELETE
  USING (auth.uid() = user_id);

-- ============================================================
-- FIM DA MIGRAÇÃO
-- ============================================================
